//
//  ViewController.swift
//  Dicelab4
//
//  Created by User on 26.10.2024.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageView1: UIImageView!
    
    
    @IBOutlet weak var Labelscore: UILabel!
    @IBOutlet weak var ImageView2: UIImageView!
    var score = 0
    var images = [ "dice-1", "dice-2", "dice-3", "dice-4", "dice-5", "dice-6" ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func BVutton(_ sender: Any) {
        let a = Int.random(in:  0...5)
        let b = Int.random(in:  0...5)
        ImageView1.image = UIImage(named : images[a])
        ImageView2.image = UIImage(named : images[b])
        score = a + 1 + b + 1
        Labelscore.text = "score : \(score)"
    }
}

