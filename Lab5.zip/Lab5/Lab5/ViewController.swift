//
//  ViewController.swift
//  Lab5
//
//  Created by User on 26.10.2024.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {
    var audio : AVAudioPlayer!
    var soundArray = ["note1","note2","note3","note4","note5","note6","note7"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func PressedButton(_ sender: UIButton) {
        var selectedSound = soundArray[(sender.tag)-1]
        playingsound(choosedSound : selectedSound)
        
    }
    func playingsound(choosedSound : String){
        let soundurl = Bundle.main.url(forResource: choosedSound , withExtension: ".wav")
        do{
            try audio = AVAudioPlayer(contentsOf: soundurl! )
            audio.prepareToPlay()
            audio.play()
        }
        catch{
            print(error)
        }
    }
}

